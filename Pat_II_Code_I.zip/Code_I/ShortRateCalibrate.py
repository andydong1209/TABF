from QuantLib import *
from collections import namedtuple
import math
from pandas import DataFrame

# This is for compatibility with QuantLib < 1.15
try:
    BlackCalibrationHelper
except:
    BlackCalibrationHelper = CalibrationHelper

today = Date(15, February, 2002);
settlement= Date(19, February, 2002);
Settings.instance().evaluationDate = today;
term_structure = YieldTermStructureHandle(FlatForward(settlement,0.04875825,Actual365Fixed()))
index = Euribor1Y(term_structure)

CalibrationData = namedtuple("CalibrationData", "start, length, volatility")
data = [CalibrationData(1, 5, 0.1148),CalibrationData(2, 4, 0.1108),CalibrationData(3, 3, 0.1070),CalibrationData(4, 2, 0.1021),CalibrationData(5, 1, 0.1000 )]

def create_swaption_helpers(data, index, term_structure, engine):
    swaptions = []
    fixed_leg_tenor = Period(1, Years)
    fixed_leg_daycounter = Actual360()
    floating_leg_daycounter = Actual360()
    for d in data:
        vol_handle = QuoteHandle(SimpleQuote(d.volatility))
        helper = SwaptionHelper(Period(d.start, Years),Period(d.length, Years),vol_handle,index,fixed_leg_tenor,fixed_leg_daycounter,floating_leg_daycounter,term_structure)
        helper.setPricingEngine(engine)
        swaptions.append(helper)
    return swaptions

def calibration_report(swaptions, data):
    columns = ["Model Price", "Market Price", "Implied Vol", "Market Vol","Rel Error Price", "Rel Error Vols"]
    report_data = []
    cum_err = 0.0
    cum_err2 = 0.0
    for i, s in enumerate(swaptions):
        model_price = s.modelValue()
        market_vol = data[i].volatility
        black_price = s.blackPrice(market_vol)
        rel_error = model_price/black_price - 1.0
        implied_vol = s.impliedVolatility(model_price,1e-5, 50, 0.0, 0.50)
        rel_error2 = implied_vol/market_vol-1.0
        cum_err += rel_error*rel_error
        cum_err2 += rel_error2*rel_error2
        report_data.append((model_price, black_price, implied_vol, market_vol, rel_error, rel_error2))
    print("Cumulative Error Price: %7.5f" % math.sqrt(cum_err))
    print("Cumulative Error Vols : %7.5f" % math.sqrt(cum_err2))
    return DataFrame(report_data,columns= columns, index=['']*len(report_data))


    model = HullWhite(term_structure)
    engine = JamshidianSwaptionEngine(model)
    swaptions = create_swaption_helpers(data, index, term_structure, engine)
    optimization_method = LevenbergMarquardt(1.0e-8,1.0e-8,1.0e-8)
    end_criteria = EndCriteria(10000, 100, 1e-6, 1e-8, 1e-8)
    model.calibrate(swaptions, optimization_method, end_criteria)    
    a, sigma = model.params()
    print("a = %6.5f, sigma = %6.5f" % (a, sigma))
    calibration_report(swaptions, data)

    constrained_model = HullWhite(term_structure, 0.05, 0.001);
    engine = JamshidianSwaptionEngine(constrained_model)
    swaptions = create_swaption_helpers(data, index, term_structure, engine)
    optimization_method = LevenbergMarquardt(1.0e-8,1.0e-8,1.0e-8)
    end_criteria = EndCriteria(10000, 100, 1e-6, 1e-8, 1e-8)
    constrained_model.calibrate(swaptions, optimization_method,end_criteria, NoConstraint(),[], [True, False])
    a, sigma = constrained_model.params()
    print("a = %6.5f, sigma = %6.5f" % (a, sigma))
    calibration_report(swaptions, data)

    model = BlackKarasinski(term_structure);
    engine = TreeSwaptionEngine(model, 100)
    swaptions = create_swaption_helpers(data, index, term_structure, engine)
    optimization_method = LevenbergMarquardt(1.0e-8,1.0e-8,1.0e-8)
    end_criteria = EndCriteria(10000, 100, 1e-6, 1e-8, 1e-8)
    model.calibrate(swaptions, optimization_method, end_criteria)
    a, sigma = model.params()
    print("a = %6.5f, sigma = %6.5f" % (a, sigma))
    calibration_report(swaptions, data)


    model = G2(term_structure);
    engine = TreeSwaptionEngine(model, 25)
    # engine = ql.G2SwaptionEngine(model, 10, 400)
    # engine = ql.FdG2SwaptionEngine(model)
    swaptions = create_swaption_helpers(data, index, term_structure, engine)
    optimization_method = LevenbergMarquardt(1.0e-8,1.0e-8,1.0e-8)
    end_criteria = EndCriteria(1000, 100, 1e-6, 1e-8, 1e-8)
    model.calibrate(swaptions, optimization_method, end_criteria)
    a, sigma, b, eta, rho = model.params()
    print("a = %6.5f, sigma = %6.5f, b = %6.5f, eta = %6.5f, rho = %6.5f " % (a, sigma, b, eta, rho))
    calibration_report(swaptions, data)

