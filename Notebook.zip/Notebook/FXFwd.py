import QuantLib as ql

class DFXForward:
    
    def __init__(self, evDate, effective, maturity, position, CCYComm, NPAComm, 
        CCYTerm, NPATerm, FXSpot, h_discTSComm, h_discTSTerm):
        self._ValueDate = evDate
        self._Effective = effective
        self._Maturity = maturity
        self._Position = position
        self._CCYComm = CCYComm
        self._NPAComm = NPAComm
        self._CCYTerm = CCYTerm
        self._NPATerm = NPATerm
        self._FXSpot = FXSpot
        self._H_discTSComm = h_discTSComm
        self._H_discTSTerm = h_discTSTerm
        
    def NPV(self):
        DfComm = self._H_discTSComm.discount(maturity)
        DfTerm = self._H_discTSTerm.discount(maturity)
        PVComm = DfComm * self._NPAComm
        PVTerm = DfTerm * self._NPATerm
        self._Value = self._Position * (PVComm * self._FXSpot - PVTerm)
        return self._Value
    
settings = ql.Settings.instance()
evDate = ql.Date(11, 7, 2011)
settings.setEvaluationDate(evDate)
Cal = ql.NullCalendar()
DC365 = ql.Actual365Fixed()
DC360 = ql.Actual360()
settlementDays = 0
refDate = Cal.advance(evDate, settlementDays, ql.Days, ql.Following, False)
BDC = ql.Unadjusted

f = 0.01
discTSComm = ql.FlatForward(settlementDays, Cal, f, DC360, ql.Simple, ql.Annual)
h_discTSComm = ql.YieldTermStructureHandle(discTSComm)

r = 0.02
discTSTerm = ql.FlatForward(settlementDays, Cal, r, DC365, ql.Simple, ql.Annual)
h_discTSTerm = ql.YieldTermStructureHandle(discTSTerm)

effective = ql.Date(11, 7, 2011)
maturity = ql.Date(11, 1, 2012)
position = 1.0
NPAComm = 1000
CCYComm = 'USD'
NPATerm = 28000
CCYComm = 'TWD'
FXSpot = 27.8
FWD = DFXForward(refDate, effective, maturity, position, CCYComm, NPAComm, CCYTerm, NPATerm, FXSpot, h_discTSComm, h_discTSTerm)
Value = FWD.NPV()
print(Value)
