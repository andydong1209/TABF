import sys

from PyQt5.QtCore import Qt
from PyQt5.QtGui import (QFont, QIcon, QKeySequence)
from PyQt5.QtWidgets import (
    QAction,
    QApplication,
    QLabel,
    QMainWindow,
    QMenu,
    QSpinBox,
    QToolBar,
    QMessageBox,
    QMdiSubWindow,
    QTextEdit,
    QMdiArea,
    QWidget,
    QPushButton,
)


class AboutForm(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Basel III SBM System - About")
        self.resize(800, 600)
        self.centralWidget = QLabel("About Wintom")
        self.centralWidget.setFont(QFont('Consolas', 20))
        self.centralWidget.setStyleSheet("color: red; background-color: lightyellow; border: 1px solid black;")
        self.centralWidget.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        self.setCentralWidget(self.centralWidget)


class MainWindow(QMainWindow):
    """Main Window."""
    count = 0
    def __init__(self, parent=None):
        """Initializer."""
        super().__init__(parent)
        self.setWindowTitle("Basel III SBM System - MainForm")
        self.resize(1600, 1000)

        self.mdi = QMdiArea()
        self.setCentralWidget(self.mdi)

        self.centralWidget = QLabel("Wintom Financial Technology")
        self.centralWidget.setFont(QFont('Consolas', 20))
        self.centralWidget.setStyleSheet("color: red; background-color: lightskyblue; border: 1px solid black;")

        self.centralWidget.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        self.setCentralWidget(self.centralWidget)

        self._createActions()
        self._createMenuBar()
        self._connectActions()
        # self._createStatusBar()


    def _createMenuBar(self):
        menuBar = self.menuBar()
        # System menu
        systemMenu = QMenu("S&ystem", self)
        menuBar.addMenu(systemMenu)
        systemMenu.addAction(self.aboutAction)
        # Separator
        systemMenu.addSeparator()
        systemMenu.addAction(self.exitAction)

        # MktData menu
        dataMenu = menuBar.addMenu("Mkt&Data")
        dataMenu.addAction(self.rateDataAction)
        dataMenu.addAction(self.fxDataAction)
        dataMenu.addAction(self.eqDataAction)
        dataMenu.addAction(self.commDataAction)

        # Position menu
        positionMenu = menuBar.addMenu("&Position")
        positionMenu.addAction(self.rateDeskAction)
        positionMenu.addAction(self.fxDeskAction)
        positionMenu.addAction(self.eqDeskAction)
        positionMenu.addAction(self.commDeskAction)

        # Scenario menu
        scenarioMenu = menuBar.addMenu("&Scenario")
        scenarioMenu.addAction(self.intraBucketAction)
        scenarioMenu.addAction(self.interBucketAction)

        # Report menu
        reportMenu = menuBar.addMenu("&Report")
        reportMenu.addAction(self.riskClassAction)
        reportMenu.addAction(self.deskClassAction)


    def _createActions(self):
        # File actions
        self.aboutAction = QAction(self)
        self.aboutAction.setText("&About")
        self.exitAction = QAction(self)
        self.exitAction.setText("E&xit")

        self.rateDataAction = QAction(self)
        self.rateDataAction.setText("RateData")
        self.fxDataAction = QAction(self)
        self.fxDataAction.setText("FXData")
        self.eqDataAction = QAction(self)
        self.eqDataAction.setText("EquityData")
        self.commDataAction = QAction(self)
        self.commDataAction.setText("CommodityData")

        self.rateDeskAction = QAction(self)
        self.rateDeskAction.setText("RateDesk")
        self.fxDeskAction = QAction(self)
        self.fxDeskAction.setText("FXDesk")
        self.eqDeskAction = QAction(self)
        self.eqDeskAction.setText("EquityDesk")
        self.commDeskAction = QAction(self)
        self.commDeskAction.setText("CommodityDesk")

        self.intraBucketAction = QAction(self)
        self.intraBucketAction.setText("IntraBucket")
        self.interBucketAction = QAction(self)
        self.interBucketAction.setText("InterBucket")

        self.riskClassAction = QAction(self)
        self.riskClassAction.setText("RiskClass")
        self.deskClassAction = QAction(self)
        self.deskClassAction.setText("DeskClass")


    def _connectActions(self):
        # Connect System actions
        self.aboutAction.triggered.connect(self.slot_aboutAction)
        self.exitAction.triggered.connect(self.slot_exitAction)

        # Connect MktData actions
        self.rateDataAction.triggered.connect(self.slot_rateDataAction)
        self.fxDataAction.triggered.connect(self.slot_fxDataAction)
        self.eqDataAction.triggered.connect(self.slot_eqDataAction)
        self.commDataAction.triggered.connect(self.slot_commDataAction)

        # Connect Position actions
        self.rateDeskAction.triggered.connect(self.slot_rateDeskAction)
        self.fxDeskAction.triggered.connect(self.slot_fxDeskAction)
        self.eqDeskAction.triggered.connect(self.slot_eqDeskAction)
        self.commDeskAction.triggered.connect(self.slot_commDeskAction)

        self.intraBucketAction.triggered.connect(self.slot_intraBucketAction)
        self.interBucketAction.triggered.connect(self.slot_interBucketAction)

        self.riskClassAction.triggered.connect(self.slot_riskClassAction)
        self.deskClassAction.triggered.connect(self.slot_deskClassAction)

    # Slots

    def slot_aboutAction(self):
        # Logic for creating a new file goes here...
        self.centralWidget.setText("About Item Selected")
        about = AboutForm(self)
        about.show()

    def slot_exitAction(self):
        self.centralWidget.setText("Exit Item Selected")
        QApplication.exit(0)

    def slot_rateDataAction(self):
        self.centralWidget.setText("RateData Item Selected")


    def slot_fxDataAction(self):
        self.centralWidget.setText("FXData Item Selected")


    def slot_eqDataAction(self):
        self.centralWidget.setText("EqData Item Selected")


    def slot_commDataAction(self):
        self.centralWidget.setText("CommData Item Selected")


    def slot_rateDeskAction(self):
        self.centralWidget.setText("RateDesk Item Selected")


    def slot_fxDeskAction(self):
        self.centralWidget.setText("FXDesk Item Selected")


    def slot_eqDeskAction(self):
        self.centralWidget.setText("EqDesk Item Selected")


    def slot_commDeskAction(self):
        self.centralWidget.setText("CommDesk Item Selected")


    def slot_interBucketAction(self):
        self.centralWidget.setText("IntraBucket Item Selected")

    def slot_intraBucketAction(self):
        self.centralWidget.setText("InterBucket Item Selected")

    def slot_riskClassAction(self):
        self.centralWidget.setText("RiskClass Item Selected")

    def slot_deskClassAction(self):
        self.centralWidget.setText("DeskClass Item Selected")


if __name__ == "__main__":
    # Create the application
    app = QApplication(sys.argv)

    # Create and show the main window
    mainwin = MainWindow()
    mainwin.show()

    # Run the event loop
    sys.exit(app.exec_())

